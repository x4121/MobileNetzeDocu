/* ---------------------------------------------------------------------------
** This software is in the public domain, furnished "as is", without technical
** support, and with no warranty, express or implied, as to its usefulness for
** any purpose.
**
** database.cpp
**
** Author: Christian Gassner
** -------------------------------------------------------------------------*/

#include "database.h"
#include <QSqlQuery>
#include <QSqlRecord>
#include <QDebug>
#include <QVariant>
#include <QSqlError>

/**
 * @brief DataBase::DataBase Ctor. Create db objects.
 */
DataBase::DataBase()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(SETTING("db_file").toString());
    if (!db.open())
        qDebug() << "DataBase db" << db.lastError();

    db_tmsi = QSqlDatabase::addDatabase("QSQLITE","TMSI");
    db_tmsi.setDatabaseName(SETTING("tmsi_db_file").toString());
    db_tmsi.setConnectOptions("QSQLITE_OPEN_READONLY=1");
    createUserTable();
}

/**
 * @brief DataBase::~DataBase Dtor. Close db files.
 */
DataBase::~DataBase()
{
    db.close();
    db_tmsi.close();
}

/**
 * @brief DataBase::readUsers Read a list of all users
 * @return The list of all users
 */
QList<BTSUser> DataBase::readUsers()
{
    QList<BTSUser> users;
    QSqlQuery query;
    if (!query.exec("SELECT s.id, s.name, s.callerid, u.username FROM SIP_BUDDIES AS s LEFT JOIN USERNAME as u ON s.id=u.id; "))
        qDebug() << "readUsers" << query.lastError();
    while (query.next()) {
        users.append(BTSUser::fromSqlQuery(query));
    }
    return users;
}

/**
 * @brief DataBase::readUsersWithTimeStamp Read a list of all users with timestamp of last access
 * @return The list of all users
 */
QList<QPair<BTSUser, qlonglong> > DataBase::readUsersWithTimeStamp()
{
    QList<QPair<BTSUser, qlonglong> > list;
    QList<BTSUser> users = readUsers();
    if (!db_tmsi.open())
        qDebug() << "DataBase db_timi" << db_tmsi.lastError();

    QSqlQuery query(db_tmsi);
    for (BTSUser user : users) {
        query.prepare("SELECT ACCESSED FROM TMSI_TABLE WHERE IMSI=:imsi;" );
        query.bindValue(":imsi",user.imsi);
        if (!query.exec())
            qDebug() << "readUsersWithActiveState" << query.lastError();

        if (query.seek(0)) {
            list.append(qMakePair(user, query.value(0).toLongLong()));
        } else { // IMSI not in db
            list.append(qMakePair(user, -1));
        }
    }
    db_tmsi.close();
    return list;
}

/**
 * @brief DataBase::readUsers Read a list of some users
 * @param ids The users to read
 * @return The list of users
 */
QList<BTSUser> DataBase::readUsers(const QList<qint32>& ids)
{
    QList<BTSUser> users;
    for (qint32 id : ids) {
        QSqlQuery query;
        query.prepare("SELECT s.id, s.name, s.callerid, u.username FROM SIP_BUDDIES AS s LEFT JOIN USERNAME as u ON s.id=u.id WHERE s.id IN (:id) ; ");
        query.addBindValue(id, QSql::Out);
        if (!query.exec())
             qDebug() << "readUsers(ids)" << query.lastError();

        while (query.next()) {
            users.append(BTSUser::fromSqlQuery(query));
        }
    }
    return users;
}

/**
 * @brief DataBase::updateUser Update the values of one user
 * @param user The user to update
 */
void DataBase::updateUser(const BTSUser &user)
{
    QSqlQuery query;
    query.prepare("UPDATE SIP_BUDDIES SET callerid=? WHERE id=?;");
    query.bindValue(0,user.number);
    query.bindValue(1,user.id);
    if (!query.exec())
        qDebug() << "updateUser0" << query.lastError();

    query.prepare("UPDATE DIALDATA_TABLE SET exten=? WHERE id=?;");
    query.bindValue(0,user.number);
    query.bindValue(1,user.id);
    if (!query.exec())
        qDebug() << "updateUser1" << query.lastError();

    // Update in USERNAME db if already exists
    query.prepare("UPDATE USERNAME SET username=:name WHERE id=:id;");
    query.bindValue(":id",user.id);
    query.bindValue(":name",user.name);
    if (!query.exec())
        qDebug() << "updateUser2" << query.lastError();

    // Insert to USERNAME db if enxtry didnt exists before
    query.prepare("INSERT OR IGNORE INTO USERNAME (id, username) VALUES(?,?);");
    query.bindValue(0,user.id);
    query.bindValue(1,user.name);
    if (!query.exec())
        qDebug() << "updateUser3" << query.lastError();
}

/**
 * @brief DataBase::deleteUser Delete a single user
 * @param id The id of the user which should be deleted
 */
void DataBase::deleteUser(qint32 id)
{
    QSqlQuery query;
    query.prepare(QStringLiteral("DELETE FROM SIP_BUDDIES WHERE id=?;"));
    query.bindValue(0,id);
    if (!query.exec())
        qDebug() << "deleteUser0" << query.lastError();

    query.prepare(QStringLiteral("DELETE FROM DIALDATA_TABLE WHERE id=?;"));
    query.bindValue(0,id);
    if (!query.exec())
        qDebug() << "deleteUser1" << query.lastError();

    query.prepare(QStringLiteral("DELETE FROM USERNAME WHERE id=?;"));
    query.bindValue(0,id);
    if (!query.exec())
        qDebug() << "deleteUser2" << query.lastError();
}

/**
 * @brief DataBase::createUserTable Create USERNAME table if not existent
 */
void DataBase::createUserTable()
{
    QSqlQuery query;
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS USERNAME (id INTEGER PRIMARY KEY NOT NULL, username VARCHAR(50));")))
        qDebug() << "createUserTable" << query.lastError();
}

