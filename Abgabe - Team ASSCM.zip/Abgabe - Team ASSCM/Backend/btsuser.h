/* ---------------------------------------------------------------------------
** This software is in the public domain, furnished "as is", without technical
** support, and with no warranty, express or implied, as to its usefulness for
** any purpose.
**
** btsuser.h
**
** Author: Christian Gassner
** -------------------------------------------------------------------------*/
#ifndef BTSUSER_H
#define BTSUSER_H

#include <QJsonObject>
#include <QSqlQuery>
#include <QVariant>

/**
 * @brief The BTSUser struct
 */
struct BTSUser {
    qint32 id;
    QString imsi;
    QString number;
    QString name;

    QJsonObject toJsonObject() {
        QJsonObject json;
        json[QStringLiteral("id")] = id;
        json[QStringLiteral("imsi")] = imsi;
        json[QStringLiteral("number")] = number;
        json[QStringLiteral("name")] = name;
        return json;
    }

    static BTSUser fromJsonObject(const QJsonObject& obj) {
        BTSUser user;
        user.id = obj.value(QStringLiteral("id")).toInt();
        user.imsi = obj.value(QStringLiteral("imsi")).toString();
        user.number = obj.value(QStringLiteral("number")).toString();
        user.name = obj.value(QStringLiteral("name")).toString();
        return user;
    }

    static BTSUser fromSqlQuery(const QSqlQuery& query) {
        BTSUser user;
        user.id = query.value(0).toInt();
        user.imsi = query.value(1).toString().remove(0,4);
        user.number = query.value(2).toString();
        user.name = query.value(3).toString();
        return user;
    }
};

#endif // BTSUSER_H

