/* ---------------------------------------------------------------------------
** This software is in the public domain, furnished "as is", without technical
** support, and with no warranty, express or implied, as to its usefulness for
** any purpose.
**
** settings.h
**
** Author: Christian Gassner
** -------------------------------------------------------------------------*/
#ifndef SETTINGS_H
#define SETTINGS_H

#include <QSettings>

// Setting macro for easy access
#define SETTING(val) QSettings(QStringLiteral("settings.ini"), QSettings::IniFormat).value(QStringLiteral(val))

// Private macro. Writes val to settings file if key doesnt exist.
#define __CHKSETTING(key, val) if ( !settings.contains(key)) {settings.setValue(QStringLiteral(key), val);}

/**
 * @brief checkSettingsFile Checks if settings.ini file exist with all needed values.
 */
inline void checkSettingsFile() {
    QSettings settings(QStringLiteral("settings.ini"), QSettings::IniFormat);
    __CHKSETTING("port", 3333);
    __CHKSETTING("tmsi_active_threshold_sec", 8*60);
    __CHKSETTING("db_file", "sqlite3.db");
    __CHKSETTING("tmsi_db_file", "TMSITable.db");
    __CHKSETTING("openbts_cmd", "/OpenBTS/OpenBTSCLI");
    __CHKSETTING("openbts_param", "-c");
    __CHKSETTING("sendsms_cmd", "sendsms");
}

#endif // SETTINGS_H

