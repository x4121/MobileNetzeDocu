/* ---------------------------------------------------------------------------
** This software is in the public domain, furnished "as is", without technical
** support, and with no warranty, express or implied, as to its usefulness for
** any purpose.
**
** socket.h
**
** Author: Christian Gassner
** -------------------------------------------------------------------------*/
#ifndef SOCKET_H
#define SOCKET_H

#include <QObject>
#include <QWebSocketServer>
#include <QWebSocket>
#include <QSettings>
#include "database.h"


/**
 * @brief The Socket class
 */
class Socket : public QObject
{
    Q_OBJECT
public:
    explicit Socket(int port, QObject *parent = 0);
    ~Socket();

Q_SIGNALS:
    void closed();

private Q_SLOTS:
    void newConnection();
    void processTextMessage(QString message);
    void socketDisconnected();
    QString executeBTSCommand(const QStringList &param);
    void sendSMSBroadcast(const QList<qint32> &userIds, const QString &sender, const QString& text);
private:
    QWebSocketServer m_socketserver;
    QList<QWebSocket* > m_clients;
    DataBase db;

    QString toJsonString(const QList<BTSUser>& users) const;
    QString toJsonString(const QList<QPair<BTSUser, qlonglong> > &users) const;
};

#endif // SOCKET_H
