/* ---------------------------------------------------------------------------
** This software is in the public domain, furnished "as is", without technical
** support, and with no warranty, express or implied, as to its usefulness for
** any purpose.
**
** socket.cpp
**
** Author: Christian Gassner
** -------------------------------------------------------------------------*/

#include "socket.h"
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>
#include <QDebug>
#include <QWebSocket>
#include <QCoreApplication>
#include <QProcess>
#include <QDateTime>

/**
 * @brief Socket::Socket Ctor. Sets up the socket server
 * @param port Port to listen on
 * @param parent
 */
Socket::Socket(int port, QObject *parent) : QObject(parent),
    m_socketserver(QStringLiteral("BTSWebService"), QWebSocketServer::NonSecureMode, this)
{
    // Connect signals of socket server to slot methods
    connect(&m_socketserver, SIGNAL(closed()), QCoreApplication::instance(), SLOT(quit()));
    connect(&m_socketserver, SIGNAL(newConnection()), this, SLOT(newConnection()));
    connect(&m_socketserver, &QWebSocketServer::acceptError, [=](QAbstractSocket::SocketError err) {
           qDebug() << "Socket error:" << err;
       });

    // Activate socket server
    m_socketserver.listen(QHostAddress::Any, port);

    qDebug() << "Listening on port" << port;
}

/**
 * @brief Socket::~Socket Dtor
 */
Socket::~Socket()
{
    qDeleteAll(m_clients);
    m_socketserver.close();
}

/**
 * @brief Socket::processTextMessage Gets called when a new message from a client arrives
 * @param message The message which arrived
 */
void Socket::processTextMessage(QString message)
{
    QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());
    if (pClient == NULL)
        return;

    // Parse to json
    QJsonParseError* error(0);
    QJsonDocument response = QJsonDocument::fromJson(message.toUtf8(), error);

    // Check if parse was ok
    if (error) {
        qCritical() << "Socket::processTextMessage: Error processing json:" << message << "err:" << error;
        return;
    }

    // Read command and process
    QVariantMap responseMap = response.object().toVariantMap();
    QString cmd = responseMap[QStringLiteral("cmd")].toString();

    if (cmd == QStringLiteral("getUsers")) {
        pClient->sendTextMessage(toJsonString(db.readUsersWithTimeStamp()));

    } else if (cmd == QStringLiteral("updateUser")) {
        db.updateUser(BTSUser::fromJsonObject(response.object()));

    } else if (cmd == QStringLiteral("deleteUser")) {
        db.deleteUser(responseMap["id"].toInt());

    } else if (cmd == QStringLiteral("sendSMSBroadcast")) {
        QList<qint32> receiver;
        foreach (QVariant var, responseMap["receiver"].toList()) {
            receiver << var.toInt();
        }
        sendSMSBroadcast(receiver, responseMap["sender"].toString(), responseMap["text"].toString());

    } else {
        qDebug() << "Socket::processTextMessage: Unknown command:" << cmd;
    }
}

/**
 * @brief Socket::newConnection Called when a new client connects
 */
void Socket::newConnection()
{
    // Get current connection
    QWebSocket *pClient = m_socketserver.nextPendingConnection();
    if (pClient != NULL) {
        pClient->ignoreSslErrors();
        qDebug() << "Socket::newConnection: client connected from" << pClient->peerAddress().toString();

        // connect signals
        connect(pClient, SIGNAL(textMessageReceived(QString)), this, SLOT(processTextMessage(QString)));
        connect(pClient, SIGNAL(disconnected()), this, SLOT(socketDisconnected()));
        m_clients.push_back(pClient);
    }
}

/**
 * @brief Socket::socketDisconnected Called when a client disconnects
 */
void Socket::socketDisconnected()
{
    QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());
    if (pClient != NULL) {
        m_clients.removeAll(pClient);
        pClient->deleteLater();
    }
}

/**
 * @brief Socket::sendSMSBroadcast Sends sms to multiple recipients
 * @param userIds Ids of recipients
 * @param sender The number of the sender
 * @param text The message
 */
void Socket::sendSMSBroadcast(const QList<qint32> &userIds, const QString& sender, const QString &text)
{
    QList<BTSUser> users = db.readUsers(userIds);
    for (BTSUser user: users) {
        QStringList param = QStringList() << SETTING("sendsms_cmd").toString() << user.imsi;
        param << (sender.isEmpty() ? "000" : sender);
        param << text;
        executeBTSCommand(param);
    }
}

/**
 * @brief Socket::executeBTSCommand Executes the openbts_cmd with a list of parameters
 * @param param The list of parameters
 * @return The result of the command
 */
QString Socket::executeBTSCommand(const QStringList& param)
{
    QProcess p;
    QString cmd(SETTING("openbts_cmd").toString() + " " + SETTING("openbts_param").toString() + " ");
    cmd.append("\"" + param.join(" ") + "\"");
    qDebug() << "executeBTSCommand" << cmd;
    p.start(cmd);
    p.waitForFinished();
    QString result = QString::fromUtf8(p.readAllStandardOutput()).trimmed();
    qDebug() << "executeBTSCommand result" << result;
    return result;
}

/**
 * @brief Socket::toJsonString Convert a list of users to a json string.
 * @param users The list of users
 * @return The resulting json string
 */
QString Socket::toJsonString(const QList<BTSUser> &users) const
{
    QJsonArray json;
    for (BTSUser user : users) {
        json.append(user.toJsonObject());
    }
    return QString::fromUtf8(QJsonDocument(json).toJson());
}

/**
 * @brief Socket::toJsonString Convert a list of users with timestamps to a json string.
 * @param users The list of pairs of users and timestamps
 * @return The resulting json string
 */
QString Socket::toJsonString(const QList<QPair<BTSUser, qlonglong> > &users) const
{
    QJsonArray jsonarray;
    for (QPair<BTSUser,qlonglong> user : users) {
        QJsonObject json = user.first.toJsonObject();
        json["active"] = (user.second > 0 && ((QDateTime::currentMSecsSinceEpoch()/1000) - user.second) < SETTING("tmsi_active_threshold_sec").toInt());
        json["lastActive"] = user.second;
        jsonarray.append(json);
    }
    return QString::fromUtf8(QJsonDocument(jsonarray).toJson());
}
