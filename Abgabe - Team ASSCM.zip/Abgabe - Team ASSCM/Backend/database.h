/* ---------------------------------------------------------------------------
** This software is in the public domain, furnished "as is", without technical
** support, and with no warranty, express or implied, as to its usefulness for
** any purpose.
**
** database.h
**
** Author: Christian Gassner
** -------------------------------------------------------------------------*/
#ifndef DATABASE_H
#define DATABASE_H

#include "btsuser.h"
#include "settings.h"
#include <QSqlDatabase>

/**
 * @brief The DataBase class
 */
class DataBase
{
public:
    DataBase();
    ~DataBase();

    QList<BTSUser> readUsers();
    QList<QPair<BTSUser, qlonglong> > readUsersWithTimeStamp();
    QList<BTSUser> readUsers(const QList<qint32> &);
    void updateUser(const BTSUser& user);
    void deleteUser(qint32 id);
    void createUserTable();

private:
    QSqlDatabase db;
    QSqlDatabase db_tmsi;
};

#endif // DATABASE_H
