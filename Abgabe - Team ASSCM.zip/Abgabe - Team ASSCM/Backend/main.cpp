/* ---------------------------------------------------------------------------
** This software is in the public domain, furnished "as is", without technical
** support, and with no warranty, express or implied, as to its usefulness for
** any purpose.
**
** main.cpp
**
** Author: Christian Gassner
** -------------------------------------------------------------------------*/

#include <QCoreApplication>
#include <QWebSocket>
#include "socket.h"
#include "settings.h"

/**
 * @brief main Main method. Check settings file, create socket and start event loop
 * @param argc
 * @param argv
 * @return
 */
int main(int argc, char *argv[])
{
    qputenv("QT_LOGGING_RULES", "qt.network.ssl.warning=false");
    QCoreApplication a(argc, argv);

    checkSettingsFile();

    Socket socket(SETTING("port").toInt());

    return a.exec();
}


