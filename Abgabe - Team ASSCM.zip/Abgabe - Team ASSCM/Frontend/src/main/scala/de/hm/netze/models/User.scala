package de.hm.netze.models

import org.scalajs.dom

import scala.scalajs.js
import scala.scalajs.js.annotation.{JSBracketAccess, JSName}

trait Moment extends js.Object {
  def format(): String = js.native

  def format(f: String): String = js.native
}

object moment extends js.Object {
  @JSBracketAccess
  def apply(timestamp: Long): Moment = js.native

  def unix(timestamp: Double): Moment = js.native
}

case class User(id: Int, imsi: String, name: String, number: String, isActive: Boolean, lastActive: Double) {
  def formatTime: String = {
    if (lastActive <= 0) {
      "never"
    } else {
      moment.unix(lastActive).format("dd, DD.MM.YY - HH:mm:ss")
    }
  }

  def showName: String = {
    if (name.size <= 0) {
      imsi
    } else {
      name
    }
  }
}

object Users {
  import org.widok._

  def update() = Socket.getUsers{
    users => {
      buffer.clear()
      users.toList.sortWith( (left, right) => left.lastActive > right.lastActive).foreach(user => buffer.append(Ref(user)))
    }
  }

  def poll(): Unit = {
    update()
    dom.setTimeout(poll _, 10000)
  }

  val buffer = Buffer[Ref[User]]()

  def all: Buffer[Ref[User]] = {
    buffer
  }

  def get(id: Int): User = {
    buffer.find(_.get.id == id).get.get
  }

  def set(id: Int, imsi: String, name: String, number: String, active: Boolean, lastActive: Double): Unit = {
    val oldUser = buffer.find{ case _ @ Ref(user) => user.id == id}.get
    buffer.replace(oldUser, Ref(User(id, imsi, name, number, active, lastActive)))
  }

  import org.widok.Buffer.Delta

  buffer.changes.attach {
    case Delta.Insert(_, Ref(user)) => {
//      println(s"Adding $user")
    }
    case Delta.Replace(reference, Ref(user)) => {
      Socket.updateUser(user)
//      println(s"Updating $user")
    }
    case Delta.Remove(Ref(user)) => {
      Socket.deleteUser(user.id)
    }
    case Delta.Clear() => {
    }
  }
}
