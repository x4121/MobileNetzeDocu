package de.hm.netze.models

import org.scalajs.dom

import scala.collection.mutable.ArrayBuffer
import scala.scalajs.js
import scala.scalajs.js.JSON

sealed abstract class Command

case class GetUsersCommand(cmd: String = "getUsers") extends Command
case class UpdateUserCommand(cmd: String = "updateUser", id: Int, imsi: String, name: String, number: String) extends Command
case class DeleteUserCommand(cmd: String = "deleteUser", id: Int) extends Command
case class SendSMSBroadcast(cmd: String = "sendSMSBroadcast", sender: String, text: String, receiver: Iterable[Int]) extends Command

object Socket {
  import rx._
  import be.doeraene.spickling._
  import be.doeraene.spickling.jsany._

  PicklerRegistry.register[GetUsersCommand]
  PicklerRegistry.register[UpdateUserCommand]
  PicklerRegistry.register[DeleteUserCommand]
  PicklerRegistry.register[SendSMSBroadcast]
//  PicklerRegistry.register[List[User]]

  case class SocketMessage(msg: String)

  def getUsers(callback: Iterable[User] => Any): Unit = {
    if (socket.isDefined) {
      socket.get.onmessage = (event: dom.MessageEvent) => {
//        println(s"Received: ${event.data}")
        val msg = JSON.parse(event.data.toString).asInstanceOf[js.Array[js.Dynamic]]

        val users = {
          val users = ArrayBuffer[User]()
          while(msg.nonEmpty) {
            val u = msg.pop()
            val name = u.selectDynamic("name").asInstanceOf[String]
            val id = u.selectDynamic("id").asInstanceOf[Int]
            val number = u.selectDynamic("number").asInstanceOf[String]
            val imsi = u.selectDynamic("imsi").asInstanceOf[String]
            val active = u.selectDynamic("active").asInstanceOf[Boolean]
            val lastActive =  u.selectDynamic("lastActive").asInstanceOf[Double]
            users.append(User(id, imsi, name, number, active, lastActive))
          }
          users.toList
        }
//        val data = PicklerRegistry.unpickle(msg).asInstanceOf[List[User]]
//        val data = msg.asInstanceOf[js.Array]


        callback(users)
      }

      send(GetUsersCommand())
    } else {
      connect()
      dom.setTimeout(() => getUsers(callback), 100)
    }
  }

  def updateUser(user: User): Unit = {
    send(UpdateUserCommand(id = user.id, imsi = user.imsi, name = user.name, number = user.number))
  }

  def deleteUser(id: Int): Unit = {
    send(DeleteUserCommand(id = id))
  }

  def sendSms(sender: String = "123456", text: String, receiver: Iterable[Int]): Unit = {
   send(SendSMSBroadcast(sender=sender, text=text, receiver=receiver))
  }

  val port = 3333
  val ip = "127.0.0.1"
  val messageEvent = "socketMessage"
  val maxSendTries = 10

  private var socket: Option[dom.WebSocket] = None
  val connected = Var(false)

  def send(cmd: Command): Unit = {
    val m = JSON.stringify(cmd match {
      case c: GetUsersCommand => js.Dynamic.literal(cmd = c.cmd)
      case c: UpdateUserCommand => js.Dynamic.literal(cmd = c.cmd, id = c.id, imsi = c.imsi, name = c.name, number = c.number)
      case c: DeleteUserCommand => js.Dynamic.literal(cmd = c.cmd, id = c.id)
      case c: SendSMSBroadcast => js.Dynamic.literal(cmd = c.cmd, sender = c.sender, text = c.text, receiver = c.receiver.to[js.Array])
      case _ => throw new IllegalArgumentException(s"Unknown command: $cmd")
    })

    var tries = 0

    def send():  Unit = {
      if (tries < maxSendTries) {
        if (socket.isDefined && connected()) {
//          println(s"Sending $m")
          socket.get.send(m)
        } else {
//          println("Not connected retry")
          connect()
          tries += 1
          dom.setTimeout(send _, 100)
        }
      } else {
        println("Apporting sending, can't connect.")
      }
    }

    send()
  }

  private def connect(): Unit = {
    if (socket.isEmpty) {
      println("Connecting to socket")
      socket = Some(new dom.WebSocket(s"ws://$ip:$port"))
      socket.get.onopen = (event: dom.Event) => connected() = true
      socket.get.onclose = (event: dom.Event) => connected() = false
      socket.get.onmessage = (event: dom.MessageEvent) => {
        println(s"Received ${event.data}")
      }
    }
  }
}
