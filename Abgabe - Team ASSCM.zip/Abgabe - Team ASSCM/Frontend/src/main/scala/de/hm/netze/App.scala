package de.hm.netze

import de.hm.netze.models.{Users, Socket}
import org.widok._

object Routes {
  val main = Route("/", pages.Index)
  val users = Route("/users", pages.Users)
  val sending = Route("/send", pages.Sending)
  val notFound = Route("/404", pages.NotFound)

  val routes = Set(main, sending, users, notFound)
}

object WebApp extends RoutingApplication(
  Routes.routes, Routes.notFound) {
  override def main() = {
    Users.poll()
    super.main()
  }
}
