package de.hm.netze.pages

import de.hm.netze.Routes
import de.hm.netze.models
import de.hm.netze.models.{Socket, User}
import de.hm.netze.pages.partials.Navigation
import org.scalajs
import org.scalajs.dom
import org.widok.Length.Percentage
import org.widok._
import org.widok.bindings.Bootstrap.{Input, Typeahead}



case class Sending() extends Page {
  import org.widok.html._
  import org.widok.bindings.Bootstrap.{ModalBuilder, Modal}

  val message = Var("")
  val targets = Buffer[Ref[User]]()

  val name = Var("")
  val id = Var(0)

  var users = models.Users.all.get.map{case _ @ Ref(user) => user}

  def updateUsers(): Unit = {
    users = models.Users.all.get.map{case _ @ Ref(user) => user}

    dom.setTimeout(updateUsers _, 5000)
  }

  def matches(input: String): Seq[(Int, String)] = {
    (if (input.size == 0) {
      users
    } else {
      val names = users.filter( user => {
        user.name.toLowerCase.startsWith(input.toLowerCase)
      })

      if (names.size == 0) {
        users.filter( user => {
          user.number.toLowerCase.startsWith(input.toLowerCase)
        })
      } else {
        names
      }
    }).map{ user => user.id -> {
      s"${user.showName} (${user.number})"
    }}
  }

  def select(selection: Int) = {
    val user = models.Users.get(selection)

    name := s"${user.showName} (${user.number})"
    id := user.id
  }

  def ready(route: InstantiatedRoute): Unit = ()

  def view(): View = div(
    Navigation(Routes.sending),
    div(
      div(
        div(
          div(
            div(
              Typeahead(Input.Text().bind(name), matches, select)/*.input.placeholder("Receiver...")*/,
              span(
                a("Add").onClick(
                  _ => {
                    val target = Ref(models.Users.get(id.get))
                    if (targets.get.find{
                      case _ @ Ref(t) => t.id == target.get.id
                    }.isEmpty) targets.append(target)
                    name := ""
                    id := 0
                  }
                ).css("btn", "btn-default")
              ).css("input-group-btn")
            ).css("input-group").width(Percentage(0.7)),
            a(
              "All"
            ).onClick(_ => {
              val users = models.Users.all.get

              users.foreach( {case user @ Ref(u)  => {
                if (targets.get.find{
                  case _ @ Ref(t) => t.id == u.id
                }.isEmpty) targets.append(user)
              }})
            }).css("btn", "btn-default"),
            a("Active").onClick(_ => {
              // TODO
              println(s"Sending $message to $targets")
              (0 until 100).foreach(_ => Socket.sendSms(sender = Navigation.currentUserNumber.get, text = message.get, receiver = targets.get.map{case _ @ Ref(user) => user.id}))
            }).css("btn", "btn-default"),
            a("Send").onClick(_ => {
              println(s"Sending $message to $targets")
              Socket.sendSms(sender = Navigation.currentUserNumber.get, text = message.get, receiver = targets.get.map{case _ @ Ref(user) => user.id})
            }).css("btn", "btn-default")
          ).css("btn-toolbar"),
          div(ul(
          targets.map{
            case t @ Ref(target) => {
              li(div(
                target.number, " (", target.showName, ")",
                a(
                  span()
                    .css("glyphicon", "glyphicon-remove").attribute("style", "display:inline;")
                )
                  .css("btn", "btn-xs").attribute("style", "display:inline;")
                  .onClick(_ => targets.remove(t))
              ).attribute("style", "display:inline;"))
            }}
        ).css("comma-list")))).css("well"),
        textarea().bind(message).attribute("style", "width:100%;height:100px;")
      ).css("well")
    ).attribute("style", "margin:15px;")
}
