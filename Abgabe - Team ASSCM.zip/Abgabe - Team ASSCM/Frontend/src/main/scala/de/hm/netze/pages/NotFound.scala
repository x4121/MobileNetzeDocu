package de.hm.netze.pages

import org.widok._

case class NotFound() extends Page {
  import org.widok.html._

  def view(): View = h1("Page not found")

  def ready(route: InstantiatedRoute) = ()
}
