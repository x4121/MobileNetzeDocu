package de.hm.netze.pages.partials

import de.hm.netze.Routes
import org.widok._
import de.hm.netze.models

object Navigation {
  import org.widok.html._

  val currentUserId = Var(-1)
  val currentUserName = Var("Login")
  val currentUserNumber = Var("")

  def makeActive(item: bindings.HTML.List.Item, isActive: Boolean): bindings.HTML.List.Item = {
    if (isActive) {
      item.css("active")
    } else {
      item
    }
  }

  def apply(active: Route) = {
    def link(name: String, route: Route): bindings.HTML.List.Item = {
      makeActive(li(
        a(name).url(route())
      ), active == route)
    }
    nav(
      div(
        div(
          button(
            span("Toggle navigation").css("sr-only"),
            span().css("icon-bar"),
            span().css("icon-bar"),
            span().css("icon-bar")
          ).attribute("type", "button")
            .css("navbar-toggle", "collapsed")
            .attribute("data-toggle", "collapse")
            .attribute("data-target", "#collapse-1"),
          a("Mobile Netze").css("navbar-brand").url(Routes.main())
        ).css("navbar-header"),
        div(
          ul(
            link("Users", Routes.users),
            link("Multi SMS", Routes.sending),
            li(
              a(currentUserName, span().css("caret")).url("#").css("dropdown-toggle").attribute("data-toggle", "dropdown").attribute("role", "button"),
              ul(
              models.Users.all.map {
                case _@Ref(user) => {
                  li(a(user.showName).css("btn", "btn-default").onClick(_ => {
                    currentUserId := user.id
                    currentUserName := user.showName
                    currentUserNumber := user.number
                  }))
                }
              }).css("dropdown-menu").attribute("role", "menu")
            ).css("dropdown")
          ).css("nav", "navbar-nav")
        ).css("collapse", "navbar-collapse")
          .id("collapse-1")
      ).css("container-fluid")
    ).css("navbar", "navbar-default")
  }
}
