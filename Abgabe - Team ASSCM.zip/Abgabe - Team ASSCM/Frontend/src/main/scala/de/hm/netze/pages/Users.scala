package de.hm.netze.pages

import de.hm.netze.models
import de.hm.netze.Routes
import de.hm.netze.models.Socket
import de.hm.netze.pages.partials.Navigation
import org.widok._
import org.widok.bindings.Bootstrap.{Modal, ModalBuilder}

case class Users() extends Page {
  import org.widok.html._

  val users = models.Users.all
  val id = Var(0)
  val imsi = Var("")
  val name = Var("")
  val number = Var("")
  val active = Var(true)
  val lastActive = Var(0.0)
  val message = Var("")

  val editModal: ModalBuilder = {
    ModalBuilder(
      Modal.Header(
        Modal.Close(editModal.dismiss),
        Modal.Title("Edit User IMSI ", imsi)
      ),
      Modal.Body(form(
        label("Name:"),
        text().bind(name),
        label(" Number:"),
        text().bind(number)
      )),
      Modal.Footer(button("Submit").onClick(_ => {
        models.Users.set(id.get, imsi.get, name.get, number.get, active.get, lastActive.get)
        editModal.dismiss()
      }))
    )
  }

  val sendModal: ModalBuilder = {
    ModalBuilder(
      Modal.Header(
        Modal.Close(sendModal.dismiss),
        Modal.Title("Send SMS to ", number, " (", name, ")")
      ),
      Modal.Body(form(
        textarea().attribute("style", "width:100%;height:100px;").bind(message)
      )),
      Modal.Footer(button("Send").onClick(_ => {
        Socket.sendSms(sender = Navigation.currentUserNumber.get, text = message.get, receiver = List(id.get))
        sendModal.dismiss()
      }))
    )
  }

  override def ready(route: InstantiatedRoute): Unit = ()

  override def view(): View = div(
    partials.Navigation(Routes.users),
    div(
      div(
        "Active user"
      ).css("panel-heading"),
      ul(
        users.filter{
          case u @ Ref(user) => user.isActive
        }.map {
          case u @ Ref(user) => li(
            div(
              user.showName,
              i(" (last active: ", user.formatTime, ")").css("text-muted"),
              a(
                span().css("glyphicon", "glyphicon-trash")
              ).css("btn", "btn-primary", "btn-xs", "pull-right")
                .onClick(_ => {
                users.remove(u)
              }),
              a(
                span(" ").css("glyphicon", "glyphicon-edit")
              ).css("btn", "btn-primary", "btn-xs", "pull-right")
                .onClick(_ => {
                id := user.id
                imsi := user.imsi
                name := user.name
                number := user.number
                active := user.isActive
                lastActive := user.lastActive
                editModal.open()
              }),
              a(
                span().css("glyphicon", "glyphicon-envelope")
              ).css("btn", "btn-primary", "btn-xs", "pull-right")
                .onClick(_ => {
                id := user.id
                imsi := user.imsi
                name := user.showName
                number := user.number
                active := user.isActive
                lastActive := user.lastActive
                sendModal.open()
              })
            ).css("btn-toolbar")
          ).css("list-group-item")
        }
      ).css("list-group")
    ).css("panel", "panel-default"),
    div(
      div(
        "Inactive user"
      ).css("panel-heading"),
      ul(
        users.filter{
          case u @ Ref(user) => !user.isActive
        }.map {
          case u @ Ref(user) => li(
            div(
              user.showName,
              i(" (last active: ", user.formatTime, ")").css("text-muted"),
              a(
                span().css("glyphicon", "glyphicon-trash")
              ).css("btn", "btn-primary", "btn-xs", "pull-right")
                .onClick(_ => {
                  users.remove(u)
              }),
              a(
                span(" ").css("glyphicon", "glyphicon-edit")
              ).css("btn", "btn-primary", "btn-xs", "pull-right")
                .onClick(_ => {
                id := user.id
                imsi := user.imsi
                name := user.name
                number := user.number
                active := user.isActive
                lastActive := user.lastActive
                editModal.open()
              }),
              a(
                span().css("glyphicon", "glyphicon-envelope")
              ).css("btn", "btn-primary", "btn-xs", "pull-right")
               .onClick(_ => {
                id := user.id
                imsi := user.imsi
                name := user.showName
                number := user.number
                active := user.isActive
                lastActive := user.lastActive
                sendModal.open()
              })
            ).css("btn-toolbar")
          ).css("list-group-item")
        }
      ).css("list-group")
    ).css("panel", "panel-default"),
    editModal,
    sendModal
  ).attribute("style", "margin:15px;")
}
