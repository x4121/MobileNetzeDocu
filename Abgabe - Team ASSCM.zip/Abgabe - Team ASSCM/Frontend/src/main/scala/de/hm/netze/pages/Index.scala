package de.hm.netze.pages

import de.hm.netze.Routes
import org.widok._

case class Index() extends Page {
  import org.widok.html._

  def ready(route: InstantiatedRoute) = ()

  def view(): View = div(
    partials.Navigation(Routes.main),
    h1("Welcome,"),
    p("to our GSM Manager")
  ).attribute("style", "margin:15px;")
}
